
Use JDK 15.
Open existing project with Intellij IDEA.

Steps:
1. Open Gradle panel, and execute build task.
2. Go to ./MostActiveCookie/CookieApplication/build/distributions/
3. Unzip CookieApplication-1.0.0-SNAPSHOT.tar
4. Go to ./CookieApplication-1.0.0-SNAPSHOT/bin
5. Prepare a csv file in this folder with name of 'cookie_log.csv'.
6. ./CookieApplication -f cookie_log.csv -d 2018-12-09
