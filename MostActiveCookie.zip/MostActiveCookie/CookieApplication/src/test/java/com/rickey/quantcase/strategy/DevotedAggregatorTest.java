package com.rickey.quantcase.strategy;

import com.rickey.quantcase.model.CookieItem;
import org.testng.annotations.Test;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

public class DevotedAggregatorTest {
    DevotedAggregator devotedAggregator = new DevotedAggregator(
            LocalDateTime.of(2019, 9, 11, 0, 0, 0), ChronoUnit.DAYS);

    @Test
    public void testRegular_CheckCount() {
        devotedAggregator.ingestCookie(new CookieItem("cookie-01",
                LocalDateTime.of(2016, 8, 5, 3, 11, 15)));

        devotedAggregator.ingestCookie(new CookieItem("cookie-11",
                LocalDateTime.of(2019, 9, 11, 3, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-11",
                LocalDateTime.of(2019, 9, 11, 4, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-11",
                LocalDateTime.of(2019, 9, 11, 5, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-12",
                LocalDateTime.of(2019, 9, 11, 6, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-12",
                LocalDateTime.of(2019, 9, 11, 7, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-13",
                LocalDateTime.of(2019, 9, 11, 8, 11, 15)));

        devotedAggregator.ingestCookie(new CookieItem("cookie-02",
                LocalDateTime.of(2021, 8, 5, 3, 11, 15)));
        devotedAggregator.ingestCookie(new CookieItem("cookie-03",
                LocalDateTime.of(2021, 9, 5, 3, 11, 15)));

        Map<String, Long> counts = devotedAggregator.getCookieCount();
        assertNotNull(counts);
        assertFalse(counts.containsKey("cookie-01"));
        assertFalse(counts.containsKey("cookie-02"));
        assertFalse(counts.containsKey("cookie-03"));

        assertTrue(counts.containsKey("cookie-11"));
        assertEquals((long) counts.get("cookie-11"), 3L);
        assertEquals((long) counts.get("cookie-12"), 2L);
        assertEquals((long) counts.get("cookie-13"), 1L);
    }
}
