package com.rickey.quantcase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

@SpringBootTest(properties = {"spring.profiles.include=test", "spring.main.allow-bean-definition-overriding=true"},
        classes = {MostActiveCookieApplication.class, MostActiveCookieApplicationTest.IntegrationTestConfiguration.class})
public class MostActiveCookieApplicationTest extends AbstractTestNGSpringContextTests {
    static ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

    @Configuration
    public static class IntegrationTestConfiguration {
        @Bean
        @Primary
        public PrintStream getOutputStream() {
            return new PrintStream(MostActiveCookieApplicationTest.outputStream);
        }
    }

    @Autowired
    MostActiveCookieApplication application;

    @BeforeMethod
    public void teardown() {
        outputStream.reset();
    }

    @Test
    public void testHappyPath() throws Exception {
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_normal.csv", "-d", "2018-12-09"};
        application.run(args);
        String[] outputLines = outputStream.toString().split("\n");

        assertNotNull(outputLines);
        assertEquals(outputLines.length, 1);
        assertEquals(outputLines[0], "AtY0laUfhglK3lC7");
    }

    @Test
    public void testMultipleResults() throws Exception {
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_multiple_result.csv", "-d", "2018-12-09"};
        application.run(args);
        String[] outputLines = outputStream.toString().split("\n");

        assertNotNull(outputLines);
        assertEquals(outputLines.length, 2);
        Set<String> set = Arrays.stream(outputLines).collect(Collectors.toSet());

        assertTrue(set.contains("AtY0laUfhglK3lC7"));
        assertTrue(set.contains("SAZuXPGUrfbcn5UA"));
    }

    @Test
    public void testEmptyResult() throws Exception {
        //no cookie logs happened on 2019-12-09
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_multiple_result.csv", "-d", "2019-12-09"};
        application.run(args);
        assertTrue(outputStream.toString().isEmpty());
    }

    @Test
    public void testEmptyLogFile() throws Exception {
        //no any line
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_empty.csv", "-d", "2019-12-09"};
        application.run(args);
        assertTrue(outputStream.toString().isEmpty());
    }

    @Test
    public void testHeadOnlyLogFile() throws Exception {
        //only has head line
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_head_only.csv", "-d", "2019-12-09"};
        application.run(args);
        assertTrue(outputStream.toString().isEmpty());
    }

    @Test
    public void test_n_LogFileNotExist() throws Exception {
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_not_exist.csv", "-d", "2019-12-09"};
        application.run(args);
        assertEquals(outputStream.toString().trim(), "Cookie log file [src/test/resources/csv/cookie_log_not_exist.csv] does not exist.");
    }

    @Test
    public void test_n_InvalidArguments_01() throws Exception {
        //invalid -h
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_not_exist.csv", "-h", "2019-12-09"};
        application.run(args);
        assertTrue(outputStream.toString().startsWith("usage: help"));
    }

    @Test
    public void test_n_InvalidArguments_02() throws Exception {
        //no required -d
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_not_exist.csv"};
        application.run(args);
        assertTrue(outputStream.toString().startsWith("usage: help"));
    }

    @Test
    public void test_n_InvalidArguments_03() throws Exception {
        String[] args = new String[]{"-f", "src/test/resources/csv/cookie_log_not_exist.csv", "-d", "2019-12"};
        application.run(args);
        assertTrue(outputStream.toString().startsWith("usage: help"));
    }
}
