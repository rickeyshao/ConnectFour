package com.rickey.quantcase.strategy;

import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

public class MostActiveStrategyTest {
    MostActiveStrategy mostActiveStrategy = new MostActiveStrategy();

    @Test
    public void testWithEmptyInput() {
        Map<String, Long> counts = new HashMap<>();
        List<String> cookies = mostActiveStrategy.apply(null);
        assertNotNull(cookies);
        assertEquals(cookies.size(), 0);
        cookies = mostActiveStrategy.apply(counts);
        assertNotNull(cookies);
        assertEquals(cookies.size(), 0);
    }

    @Test
    public void testWithOneReturn() {
        Map<String, Long> counts = new HashMap<>();
        counts.put("cookie-01", 10L);
        counts.put("cookie-02", 8L);
        counts.put("cookie-03", 8L);
        counts.put("cookie-04", 1L);
        List<String> cookies = mostActiveStrategy.apply(counts);
        assertNotNull(cookies);
        assertEquals(cookies.size(), 1);
        assertEquals(cookies.get(0), "cookie-01");
    }

    @Test
    public void testWithMultipleReturn() {
        Map<String, Long> counts = new HashMap<>();
        counts.put("cookie-01", 10L);
        counts.put("cookie-02", 10L);
        counts.put("cookie-03", 1L);
        counts.put("cookie-04", 8L);
        List<String> cookies = mostActiveStrategy.apply(counts);
        assertNotNull(cookies);
        assertEquals(cookies.size(), 2);
        HashSet<String> set = new HashSet<>(cookies);
        assertTrue(cookies.contains("cookie-01"));
        assertTrue(cookies.contains("cookie-02"));
    }
}
