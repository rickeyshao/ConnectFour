package com.rickey.quantcase.strategy;

import com.rickey.csv.exception.BadFormatException;
import com.rickey.quantcase.model.CookieItem;
import org.testng.annotations.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class CookieCsvLineMapperTest {
    CookieCsvLineMapper lineMapper = new CookieCsvLineMapper();

    @Test
    public void test_p_MapWithValidLine() throws BadFormatException {
        CookieItem item = lineMapper.toItem(new String[]{"SAZuXPGUrfbcn5UA", "2018-12-09T10:13:00+00:00"});
        assertNotNull(item);
        LocalDateTime dateTime = LocalDateTime.parse("2018-12-09T10:13:00+00:00", DateTimeFormatter.ISO_ZONED_DATE_TIME);
        assertEquals(item.getName(), "SAZuXPGUrfbcn5UA");
        assertEquals(item.getTime(), dateTime);
    }

    @Test(expectedExceptions = {BadFormatException.class})
    public void test_n_MapWithLessField() throws BadFormatException {
        lineMapper.toItem(new String[]{"SAZuXPGUrfbcn5UA"});
    }

    @Test(expectedExceptions = {BadFormatException.class})
    public void test_n_MapWithMoreField() throws BadFormatException {
        CookieItem item = lineMapper.toItem(new String[]{"SAZuXPGUrfbcn5UA", "2018-12-09T10:13:00+00:00", "good"});
    }

    @Test(expectedExceptions = {BadFormatException.class})
    public void test_n_MapWithInvalidDatetime() throws BadFormatException {
        lineMapper.toItem(new String[]{"SAZuXPGUrfbcn5UA", "2018-12-99T10:13:00+00:00"});
    }

    @Test(expectedExceptions = {BadFormatException.class})
    public void test_n_MapWithEmptyValues() throws BadFormatException {
        lineMapper.toItem(new String[]{});
    }

    @Test(expectedExceptions = {BadFormatException.class})
    public void test_n_MapWithNull() throws BadFormatException {
        lineMapper.toItem(null);
    }
}
