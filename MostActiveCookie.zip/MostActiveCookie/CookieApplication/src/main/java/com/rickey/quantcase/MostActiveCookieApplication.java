package com.rickey.quantcase;

import com.rickey.quantcase.service.ICookieService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.PrintStream;
import java.util.List;

@Slf4j
@SpringBootApplication
public class MostActiveCookieApplication implements CommandLineRunner {
    private PrintStream printStream;
    private ICookieService cookieService;

    @Autowired
    public void setPrintStream(PrintStream printStream) {
        this.printStream = printStream;
    }

    @Autowired
    public void setCookieService(ICookieService cookieService) {
        this.cookieService = cookieService;
    }

    public static void main(String[] args) {
        SpringApplication.run(MostActiveCookieApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("STARTING MostActiveCookieApplication");
        List<String> activeCookies = cookieService.findMostActiveCookies(args);
        if (activeCookies == null) {
            log.debug("activeCookies == null");
            return;
        }
        log.info("Size of activeCookies: {}.", activeCookies.size());
        for (String cookieName : activeCookies) {
            printStream.println(cookieName);
        }
        log.info("MostActiveCookieApplication FINISHED");
    }
}
