package com.rickey.quantcase.args;

import com.rickey.quantcase.model.ActiveCookieArgument;
import org.apache.commons.cli.ParseException;

public interface IArgumentParser {
    ActiveCookieArgument parseArguments(String[] args) throws ParseException;
}
