package com.rickey.quantcase.model;

public enum CacheMode {
    PERSIST,
    NONE
}
