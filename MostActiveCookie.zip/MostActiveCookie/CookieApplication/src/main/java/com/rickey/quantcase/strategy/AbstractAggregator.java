package com.rickey.quantcase.strategy;

import com.rickey.quantcase.model.CookieItem;
import com.rickey.quantcase.model.TimeRange;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public abstract class AbstractAggregator implements ICookieAggregator {
    protected TimeRange timeRange;
    protected ChronoUnit timeUnit;

    public AbstractAggregator(LocalDateTime time, ChronoUnit timeUnit) {
        this.timeRange = buildTimeRange(time, timeUnit);
        this.timeUnit = timeUnit;
    }

    protected boolean timeMatch(CookieItem item) {
        return timeMatch(this.timeRange, item);
    }

    protected boolean timeMatch(TimeRange timeRange, CookieItem item) {
        LocalDateTime time = item.getTime();
        return (time.isEqual(timeRange.getStartTime()) || time.isAfter(timeRange.getStartTime()))
                && time.isBefore(timeRange.getEndTime());
    }

    public static TimeRange buildTimeRange(LocalDateTime time, ChronoUnit timeUnit) {
        LocalDateTime startTime = switch (timeUnit) {
            case HOURS -> LocalDateTime.of(time.getYear(), time.getMonthValue(), time.getDayOfMonth(), time.getHour(), 0);
            case DAYS -> LocalDateTime.of(time.getYear(), time.getMonthValue(), time.getDayOfMonth(), 0, 0);
            default -> throw new RuntimeException("Not supported timeunit: %s.".formatted(timeUnit));
        };
        LocalDateTime endTime = startTime.plus(1, timeUnit);
        return new TimeRange(startTime, endTime);
    }
}
