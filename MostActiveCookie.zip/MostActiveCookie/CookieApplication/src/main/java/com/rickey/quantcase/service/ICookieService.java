package com.rickey.quantcase.service;

import java.util.List;

public interface ICookieService {
    List<String> findMostActiveCookies(String[] args);
}
