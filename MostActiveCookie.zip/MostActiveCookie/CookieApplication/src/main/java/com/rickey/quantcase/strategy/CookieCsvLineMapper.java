package com.rickey.quantcase.strategy;

import com.rickey.csv.exception.BadFormatException;
import com.rickey.csv.mapping.ICsvLineMapper;
import com.rickey.quantcase.model.CookieItem;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Convert cookie log line into a cookie item instance.
 */
@Slf4j
public class CookieCsvLineMapper implements ICsvLineMapper<CookieItem> {
    private static final DateTimeFormatter COOKIE_TIME_FORMATTER = DateTimeFormatter.ISO_ZONED_DATE_TIME;

    @Override
    public CookieItem toItem(String[] line) throws BadFormatException {
        if (line == null || line.length != 2 || line[0].isBlank()) {
            throw new BadFormatException("Invalid cookie log line.");
        }
        try {
            CookieItem cookieItem = new CookieItem();
            cookieItem.setName(line[0]);
            cookieItem.setTime(LocalDateTime.parse(line[1], COOKIE_TIME_FORMATTER));
            return cookieItem;
        } catch (Exception e) {
            log.error("Invalid cookie log line: {}, {}", line[0], line[1]);
            throw new BadFormatException("Invalid cookie log line.");
        }
    }
}
