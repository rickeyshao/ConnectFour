package com.rickey.quantcase.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.PrintStream;

@Configuration
public class ActiveCookieAppConfig {
    @Bean
    public PrintStream outputStream() {
        return System.out;
    }
}
