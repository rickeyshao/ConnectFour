package com.rickey.quantcase.args;

import com.rickey.quantcase.model.ActiveCookieArgument;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

@Slf4j
@Component
public class ActiveCookieArgumentParser implements IArgumentParser {
    //we may support active cookies in some hour with -h '2018-12-09T08' later
//    private static DateTimeFormatter TIME_FORMATTER_HOUR;

    //TIME_FORMATTER_DATE can support paring '2018-12-09' to a LocalDateTime instance
    private static DateTimeFormatter TIME_FORMATTER_DATE = new DateTimeFormatterBuilder().append(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0)
            .toFormatter();

    private PrintStream printStream;

    @Autowired
    public void setPrintStream(PrintStream printStream) {
        this.printStream = printStream;
    }

    /**
     * Parse the arguments passed in, and validate the format.
     *
     * @param args
     * @return An instance of ActiveCookieArgument.
     * @throws ParseException
     */
    public ActiveCookieArgument parseArguments(String[] args) throws ParseException {
        Options options = buildOptions();
        CommandLineParser parser = new DefaultParser();

        try {
            CommandLine cmd = parser.parse(options, args);
            ActiveCookieArgument argument = new ActiveCookieArgument();
            argument.setCookieLogFile(cmd.getOptionValue('f'));
            //currently, always true
            if (cmd.getOptionValue('d') != null) {
                argument.setTimeUnit(ChronoUnit.DAYS);
                argument.setDateTime(LocalDateTime.parse(cmd.getOptionValue('d'), TIME_FORMATTER_DATE));
            }
            //we may support -h hour later
            return argument;
        } catch (ParseException | DateTimeParseException e) {
            log.error("Parse arguments failed.", e);
            printHelp(options);
            ParseException ex = null;
            if (!(ex instanceof ParseException)) {
                ex = new ParseException(e.getMessage());
                ex.initCause(e);
            } else {
                ex = (ParseException) e;
            }
            throw ex;
        }
    }

    private Options buildOptions() {
        Options options = new Options();
        Option option = new Option("f", "file", true, "Cookie log file path.");
        option.setRequired(true);
        options.addOption(option);
        option = new Option("d", "date", true, "Find active cookie(s) record on this day with format yyyy-MM-dd.");
        option.setRequired(true);
        options.addOption(option);
        return options;
    }

    private void printHelp(Options options) {
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp(new PrintWriter(printStream, true), HelpFormatter.DEFAULT_WIDTH, "help", null,
                options, HelpFormatter.DEFAULT_LEFT_PAD, HelpFormatter.DEFAULT_DESC_PAD, null);
    }
}
