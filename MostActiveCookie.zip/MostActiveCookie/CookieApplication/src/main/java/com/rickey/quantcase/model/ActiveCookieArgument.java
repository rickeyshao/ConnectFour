package com.rickey.quantcase.model;

import lombok.Data;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Data
public class ActiveCookieArgument {
    private String cookieLogFile;
    private LocalDateTime dateTime;
    private ChronoUnit timeUnit;
}
