package com.rickey.quantcase.service;

import com.rickey.csv.CsvReader;
import com.rickey.csv.CsvReaderBuilder;
import com.rickey.csv.exception.BadFormatException;
import com.rickey.quantcase.args.IArgumentParser;
import com.rickey.quantcase.model.ActiveCookieArgument;
import com.rickey.quantcase.model.CacheMode;
import com.rickey.quantcase.model.CookieItem;
import com.rickey.quantcase.strategy.CookieCsvLineMapper;
import com.rickey.quantcase.strategy.DevotedAggregator;
import com.rickey.quantcase.strategy.ICookieAggregator;
import com.rickey.quantcase.strategy.ICookieFetchStrategy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.cli.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class ActiveCookieService implements ICookieService {
    //whether to cache processing result for all time range
    private CacheMode cacheMode;
    private IArgumentParser argumentParser;
    //currently, the fetch strategy is 'Most Active', we can support 'TOP 10' strategy if required
    private ICookieFetchStrategy cookieFetchStrategy;
    private PrintStream printStream;

    @Value("${mode:NONE}")
    public void setCacheMode(CacheMode cacheMode) {
        this.cacheMode = cacheMode;
    }

    @Autowired
    public void setArgumentParser(IArgumentParser argumentParser) {
        this.argumentParser = argumentParser;
    }

    @Autowired
    public void setCookieFetchStrategy(ICookieFetchStrategy fetchStrategy) {
        this.cookieFetchStrategy = fetchStrategy;
    }

    @Autowired
    public void setPrintStream(PrintStream printStream) {
        this.printStream = printStream;
    }

    public List<String> findMostActiveCookies(String[] args) {
        String logFilePath = null;
        try {
            ActiveCookieArgument argument = argumentParser.parseArguments(args);
            logFilePath = argument.getCookieLogFile();
            ICookieAggregator aggregator = new DevotedAggregator(argument.getDateTime(), argument.getTimeUnit());
            CsvReader<CookieItem> csvReader = new CsvReaderBuilder<CookieItem>(new FileReader(logFilePath))
                    .withLineMapper(new CookieCsvLineMapper())
                    .build();
            Iterator<CookieItem> iterator = csvReader.iterator();
            while (iterator.hasNext()) {
                aggregator.ingestCookie(iterator.next());
            }
            Map<String, Long> cookieCounts = aggregator.getCookieCount();
            List<String> result = cookieFetchStrategy.apply(cookieCounts);
            return result;
        } catch (ParseException e) {
            //swallow it
        } catch (FileNotFoundException e) {
            log.error("FileNotFoundException", e);
            printStream.println("Cookie log file [%s] does not exist.".formatted(logFilePath));
        } catch (BadFormatException e) {
            log.error("BadFormatException", e);
            printStream.println("Invalid format in Cookie log file [%s].".formatted(logFilePath));
        } catch (IOException e) {
            log.error("IOException", e);
            printStream.println("Fail to read Cookie log file [%s].".formatted(logFilePath));
        }

        return null;
    }
}
