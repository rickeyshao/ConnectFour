package com.rickey.quantcase.strategy;

import java.util.Map;

/**
 * Customers may run this application multiple times against the same log file with different 'date'.
 * To accelerate execution speed, we can cache the process result for the whole log file.
 * We may cache the result in file system, database, or cache system like redis.
 */
public interface ICacheProvider {
    void initStore(String storeId);

    void removeStore(String storeId);

    boolean storeExists(String storeId);

    void put(String storeId, String key, Map<String, Long> itemCounts);

    Map<String, Long> get(String storeId, String key);
}
