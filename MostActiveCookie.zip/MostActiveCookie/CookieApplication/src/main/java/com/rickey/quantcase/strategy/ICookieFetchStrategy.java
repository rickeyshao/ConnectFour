package com.rickey.quantcase.strategy;

import java.util.List;
import java.util.Map;

/**
 * Given the aggregation result of the specified period, return the cookie names according to some strategy.
 */
public interface ICookieFetchStrategy {
    List<String> apply(Map<String, Long> cookieCounts);
}
