package com.rickey.quantcase.strategy;

import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * With the given the cookies and count, return the cookie names whose count is maximum.
 * If there are multiple cookies which have the same max count, return all of them.
 */
@Component
public class MostActiveStrategy implements ICookieFetchStrategy {
    @Override
    public List<String> apply(Map<String, Long> cookieCounts) {
        if (cookieCounts == null || cookieCounts.size() < 1) {
            return Collections.EMPTY_LIST;
        }
        List<Object[]> countList = cookieCounts.entrySet().stream()
                .map(entry -> new Object[]{entry.getKey(), entry.getValue()}).collect(Collectors.toList());
        long maxCount = (long) (countList.stream().max(Comparator.comparingLong(item -> (long) item[1])).get())[1];
        if (maxCount < 1) {
            return Collections.EMPTY_LIST;
        }
        List<String> result = countList.stream().filter(item -> (long) item[1] == maxCount)
                .map(item -> (String) item[0]).collect(Collectors.toList());
        return result;
    }
}
