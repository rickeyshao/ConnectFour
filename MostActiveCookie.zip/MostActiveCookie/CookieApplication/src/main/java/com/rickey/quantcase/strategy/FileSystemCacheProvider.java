package com.rickey.quantcase.strategy;

import java.util.Map;

/**
 * TODO do not support CacheMode.PERSIST now
 */
public class FileSystemCacheProvider implements ICacheProvider {
    @Override
    public void initStore(String storeId) {
        //TODO
    }

    @Override
    public void removeStore(String storeId) {
        //TODO
    }

    @Override
    public boolean storeExists(String storeId) {
        return false;//TODO
    }

    @Override
    public void put(String storeId, String key, Map<String, Long> itemCounts) {
        //TODO
    }

    @Override
    public Map<String, Long> get(String storeId, String key) {
        return null;//TODO
    }
}
