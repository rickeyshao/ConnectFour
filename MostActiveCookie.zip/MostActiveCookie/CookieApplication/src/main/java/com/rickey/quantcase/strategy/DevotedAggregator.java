package com.rickey.quantcase.strategy;

import com.rickey.quantcase.model.CookieItem;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

/**
 * Only record the aggregation result of the cookies which happened in the specified time range.
 * Omit cookies happened out of the time range.
 */
public class DevotedAggregator extends AbstractAggregator {
    private final Map<String, Long> itemCounts;

    public DevotedAggregator(LocalDateTime time, ChronoUnit timeUnit) {
        super(time, timeUnit);
        itemCounts = new HashMap<>();
    }

    @Override
    public void ingestCookie(CookieItem cookieItem) {
        if (timeMatch(cookieItem)) {
            itemCounts.put(cookieItem.getName(), itemCounts.getOrDefault(cookieItem.getName(), 0L) + 1);
        }
    }

    @Override
    public Map<String, Long> getCookieCount() {
        return itemCounts;
    }
}
