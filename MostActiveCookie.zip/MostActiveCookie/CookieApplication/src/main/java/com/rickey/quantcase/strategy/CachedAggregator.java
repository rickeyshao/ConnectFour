package com.rickey.quantcase.strategy;

import com.rickey.quantcase.model.CookieItem;
import com.rickey.quantcase.model.TimeRange;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

/**
 * When processing cookie records, we cache the aggregation result of all the records based on the time unit.
 */
public class CachedAggregator extends AbstractAggregator {
    private String id;
    private ICacheProvider cacheProvider;
    private boolean cached;
    private Map<String, Map<String, Long>> allCookieCounts; //TODO Use LRU cache

    private TimeRange currentTimeRange = null;
    private Map<String, Long> currentCookieCount = new HashMap<>();

    public CachedAggregator(LocalDateTime time, ChronoUnit timeUnit, String id, ICacheProvider cacheProvider) {
        super(time, timeUnit);
        this.id = id;
        this.cacheProvider = cacheProvider;
        this.cached = cacheProvider.storeExists(id);
        this.allCookieCounts = new HashMap<>();
    }

    public void removeCache() {
        cacheProvider.removeStore(id);
    }

    public void ingestComplete() {
        removeCache();
        cacheProvider.initStore(id);
        for (Map.Entry<String, Map<String, Long>> entry : allCookieCounts.entrySet()) {
            cacheProvider.put(id, entry.getKey(), entry.getValue());
        }
        cached = true;
    }

    @Override
    public void ingestCookie(CookieItem cookieItem) {
        if (cached) {
            return;
        }
        if (currentTimeRange == null) {
            currentTimeRange = buildTimeRange(cookieItem.getTime(), timeUnit);
        }
        String cookieName = cookieItem.getName();

        if (currentTimeRange == null || !timeMatch(currentTimeRange, cookieItem)) {
            if (currentTimeRange != null) {
                cacheProvider.put(id, timeToSecondString(currentTimeRange.getStartTime()), currentCookieCount);
            }
            currentTimeRange = buildTimeRange(cookieItem.getTime(), timeUnit);
            currentCookieCount = new HashMap<>();
        }

        currentCookieCount.put(cookieName, currentCookieCount.getOrDefault(cookieName, 0L) + 1);
    }

    @Override
    public Map<String, Long> getCookieCount() {
        return getCookieCount(timeRange.getStartTime());
    }

    public Map<String, Long> getCookieCount(LocalDateTime time) {
        //lazy load
        String key = timeToSecondString(time);
        if (allCookieCounts.containsKey(key)) {
            return allCookieCounts.get(key);
        }
        Map<String, Long> cookieCount = cacheProvider.get(id, key);
        allCookieCounts.put(key, cookieCount);
        return cookieCount;
    }

    private String timeToSecondString(LocalDateTime time) {
        return String.valueOf(time.toEpochSecond(ZoneOffset.UTC));
    }
}
