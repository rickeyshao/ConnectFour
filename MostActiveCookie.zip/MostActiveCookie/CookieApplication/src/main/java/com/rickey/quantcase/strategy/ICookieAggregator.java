package com.rickey.quantcase.strategy;

import com.rickey.quantcase.model.CookieItem;

import java.util.Map;

/**
 * Consume log entries one by one, and return the aggregation result.
 * What's the exact aggregation result depends on the implementation.
 */
public interface ICookieAggregator {
    void ingestCookie(CookieItem cookieItem);

    Map<String, Long> getCookieCount();
}
