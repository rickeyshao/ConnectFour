package com.rickey.csv;

import com.rickey.csv.exception.BadFormatException;
import com.rickey.csv.parser.CsvLineParser;
import org.mockito.Mock;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

public class CsvReaderTest {

    @Test
    public void testDefaultCsvReader_ReadAll() throws IOException, BadFormatException {
        FileReader reader = new FileReader(this.getClass().getResource("/csv_with_header.csv").getFile());
        CsvReader<String[]> csvReader = new CsvReader<String[]>(new CsvLineParser(), reader, true, raw -> raw);

        List<String[]> allLines = csvReader.readAll();
        assertNotNull(allLines);
        assertTrue(allLines.size() > 0);
        String[] header = csvReader.getHeader();
        assertNotNull(header);
        assertTrue(header.length > 0);
        assertEquals(header[0], "cookie");
        assertEquals(header[1], "timestamp");
    }

    @Test
    public void testDefaultCsvReader_ReadWithIterator() throws IOException, BadFormatException {
        FileReader reader = new FileReader(this.getClass().getResource("/csv_with_header.csv").getFile());
        CsvReader<String[]> csvReader = new CsvReaderBuilder<String[]>(reader)
                .withLineParse(new CsvLineParser())
                .withLineMapper(raw -> raw)
                .build();
        Iterator<String[]> iterator = csvReader.iterator();
        List<String[]> allLines = new LinkedList<>();
        while (iterator.hasNext()) {
            allLines.add(iterator.next());
        }
        assertNotNull(allLines);
        assertTrue(allLines.size() > 0);
        String[] header = csvReader.getHeader();
        assertNotNull(header);
        assertTrue(header.length > 0);
        assertEquals(header[0], "cookie");
        assertEquals(header[1], "timestamp");
    }
}
