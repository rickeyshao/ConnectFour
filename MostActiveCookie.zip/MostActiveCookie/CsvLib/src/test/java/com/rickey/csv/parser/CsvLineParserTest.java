package com.rickey.csv.parser;

import com.rickey.csv.exception.BadFormatException;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

public class CsvLineParserTest {

    @Test
    void testDefaultParser_RegularLine() throws BadFormatException {
        CsvLineParser parser = new CsvLineParser();
        String[] parseResult = parser.parseLine("name,22,jim");
        assertNotNull(parseResult);
        assertEquals(parseResult.length, 3);
        assertEquals(parseResult[0], "name");
        assertEquals(parseResult[1], "22");
        assertEquals(parseResult[2], "jim");
    }

    @Test
    void testDefaultParser_Escape() throws BadFormatException {
        CsvLineParser parser = new CsvLineParser();
        String[] parseResult = parser.parseLine("name\\,22\\,j\\im");
        assertNotNull(parseResult);
        assertEquals(parseResult.length, 1);
        assertEquals(parseResult[0], "name,22,j\\im");
    }

    @Test
    void testDefaultParser_Trim() throws BadFormatException {
        CsvLineParser parser = new CsvLineParser();
        String[] parseResult = parser.parseLine(" name , 22,j im");
        assertNotNull(parseResult);
        assertEquals(parseResult.length, 3);
        assertEquals(parseResult[0], "name");
        assertEquals(parseResult[1], "22");
        assertEquals(parseResult[2], "j im");
    }

    @Test(expectedExceptions = {BadFormatException.class})
    void testDefaultParser_DifferentColumns() throws BadFormatException {
        CsvLineParser parser = new CsvLineParser();
        parser.parseLine("name,22,jim");
        parser.parseLine("name,22,jim,kk");
    }
}
