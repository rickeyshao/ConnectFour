package com.rickey.csv.mapping;

import com.rickey.csv.exception.BadFormatException;

/**
 * Convert a csv line to an instance of T
 */
public interface ICsvLineMapper<T> {
    T toItem(String[] line) throws BadFormatException;
}
