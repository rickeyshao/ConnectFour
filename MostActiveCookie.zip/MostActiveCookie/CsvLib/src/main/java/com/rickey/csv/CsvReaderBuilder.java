package com.rickey.csv;

import com.rickey.csv.exception.BadFormatException;
import com.rickey.csv.mapping.ICsvLineMapper;
import com.rickey.csv.parser.CsvLineParser;
import com.rickey.csv.parser.ILineParser;
import com.rickey.csv.parser.LineParseBuilder;

import java.io.IOException;
import java.io.Reader;

public class CsvReaderBuilder<T> {
    private final LineParseBuilder lineParseBuilder;
    private final Reader reader;
    private ILineParser lineParser;
    private ICsvLineMapper<T> lineMapper;
    private boolean hasHeader = true;

    public CsvReaderBuilder(Reader reader) {
        if (reader == null) {
            throw new IllegalArgumentException("Invalid reader.");
        }
        this.reader = reader;
        lineParseBuilder = new LineParseBuilder(); //default parser builder
        lineParser = lineParseBuilder.build();
    }

    public CsvReaderBuilder<T> withLineParse(ILineParser lineParser) {
        this.lineParser = lineParser;
        return this;
    }

    public CsvReaderBuilder<T> withLineMapper(ICsvLineMapper<T> lineMapper) {
        this.lineMapper = lineMapper;
        return this;
    }

    public CsvReaderBuilder<T> withHasHeader(boolean hasHeader) {
        this.hasHeader = hasHeader;
        return this;
    }

    public CsvReader<T> build() throws IOException, BadFormatException {
        if (lineMapper == null) {
            throw new RuntimeException("No line mapper is configured.");
        }
        return new CsvReader<>(lineParser, reader, hasHeader, lineMapper);
    }

    public static CsvReader<String[]> defaultCsvReader(Reader reader) throws IOException, BadFormatException {
        return new CsvReader<>(new CsvLineParser(), reader, true, line -> line);
    }
}
