package com.rickey.csv.mapping;

import java.util.Map;

public interface IFieldNameLineMapper<T> extends ICsvLineMapper<T> {
    Map<String, String> getFieldColumnMapping();

    Class getItemClass();
}
