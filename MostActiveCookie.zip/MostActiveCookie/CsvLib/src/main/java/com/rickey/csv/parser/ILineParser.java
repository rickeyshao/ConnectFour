package com.rickey.csv.parser;

import com.rickey.csv.exception.BadFormatException;

public interface ILineParser {
    /**
     * The default separator
     */
    char DEFAULT_SEPARATOR = ',';

    /**
     * The default escape char
     */
    char DEFAULT_ESCAPE = '\\';

    /**
     * Default of whether trim whitespace of field values
     */
    boolean DEFAULT_TRIM_VALUE = true;

    /**
     * @return The separator for this parser.
     */
    char getSeparator();

    /**
     * @return The escape char for this parser.
     */
    char getEscape();

    /**
     * Separate a line string into string array with the given separator.
     *
     * @param nextLine Line to be parsed.
     * @return The list of column values
     * @throws BadFormatException When something is wrong during parsing
     */
    String[] parseLine(String nextLine) throws BadFormatException;
}
