package com.rickey.csv.parser;

import com.rickey.csv.exception.BadFormatException;

import java.util.ArrayList;
import java.util.List;

public class CsvLineParser implements ILineParser {
    private final char separator;
    private final char escape;
    private final boolean trimFieldValue;
    private int columnCount = -1;

    public CsvLineParser() {
        this(ILineParser.DEFAULT_SEPARATOR, ILineParser.DEFAULT_ESCAPE, ILineParser.DEFAULT_TRIM_VALUE);
    }

    CsvLineParser(char separator, char escape, boolean trimFieldValue) {
        this.separator = separator;
        this.escape = escape;
        this.trimFieldValue = trimFieldValue;
    }

    @Override
    public char getSeparator() {
        return separator;
    }

    @Override
    public char getEscape() {
        return escape;
    }

    @Override
    public String[] parseLine(String line) throws BadFormatException {
        //sometimes, there is no header, columnCount == -1 here
        List<String> result = columnCount == -1 ? new ArrayList<>() : new ArrayList<>(columnCount);
        StringBuilder stringBuilder = new StringBuilder(line.length());
        boolean inEscape = false;
        for (char c : line.toCharArray()) {
            if (c == escape && !inEscape) {
                inEscape = true;
            } else if (inEscape) {
                //when in escape, current char is impossible a real separator
                inEscape = false;
                if (c == separator || c == escape) {
                    stringBuilder.append(c);
                } else {
                    stringBuilder.append(escape);
                    stringBuilder.append(c);
                }
            } else {
                if (c == separator) {
                    result.add(takeValue(stringBuilder));
                    stringBuilder.setLength(0);
                } else {
                    stringBuilder.append(c);
                }
            }
        }
        result.add(takeValue(stringBuilder));
        if (columnCount == -1) {
            columnCount = result.size();
        } else if (columnCount != result.size()) {
            throw new BadFormatException("Different column count found.");
        }
        return result.toArray(new String[0]);
    }

    private String takeValue(StringBuilder stringBuilder) {
        String value = stringBuilder.toString();
        if (trimFieldValue) {
            value = value.trim();
        }
        return value;
    }
}
