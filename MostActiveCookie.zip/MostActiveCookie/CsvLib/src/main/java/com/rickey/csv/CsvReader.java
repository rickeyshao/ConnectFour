package com.rickey.csv;

import com.rickey.csv.exception.BadFormatException;
import com.rickey.csv.mapping.ICsvLineMapper;
import com.rickey.csv.parser.ILineParser;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * A reader which can read lines from a csv file, and convert to an instance of T with the provided line mapper.
 * Support both read all lines, and read lines one by one.
 * Note: After reading all lines, you should not read lines one by one again. And vise versa.
 */
public class CsvReader<T> implements Closeable, Iterable<T> {
    private final ILineParser lineParser;
    private final BufferedReader bufferedReader;
    private boolean hasHeader;
    private String[] header;
    private ICsvLineMapper<T> lineMapper;

    //Use CsvReaderBuilder to build a default CsvReader

    public CsvReader(ILineParser lineParser, Reader reader, boolean hasHeader, ICsvLineMapper<T> lineMapper) throws IOException, BadFormatException {
        this.lineParser = lineParser;
        this.bufferedReader = (reader instanceof BufferedReader ? (BufferedReader) reader : new BufferedReader(reader));
        ;
        this.hasHeader = hasHeader;
        this.lineMapper = lineMapper;

        if (this.hasHeader) {
            String headLine = bufferedReader.readLine();
            if (headLine == null) {
                //empty csv file, do not throw exception here
                headLine = "";
            }
            header = lineParser.parseLine(headLine);
        }
    }

    public String[] getHeader() {
        return header;
    }

    @Override
    public void close() throws IOException {
        bufferedReader.close();
    }

    @Override
    public Iterator<T> iterator() {
        try {
            return new CsvReaderIterator();
        } catch (IOException | BadFormatException e) {
            throw new RuntimeException(e);
        }
    }

    public List<T> readAll() throws IOException, BadFormatException {
        List<T> allItems = new LinkedList<>();
        CsvReaderIterator iterator = new CsvReaderIterator();
        while (iterator.hasNext()) {
            T nextItem = iterator.next();
            if (nextItem != null) {
                allItems.add(nextItem);
            }
        }
        return allItems;
    }

    class CsvReaderIterator implements Iterator<T> {
        private T nextItem;

        CsvReaderIterator() throws IOException, BadFormatException {
            prepareNextItem();
        }

        private void prepareNextItem() throws IOException, BadFormatException {
            String lineStr = bufferedReader.readLine();
            while (lineStr != null && lineStr.isBlank()) {
                lineStr = bufferedReader.readLine();
            }
            if (lineStr == null) {
                nextItem = null;
            } else {
                String[] lineParts = lineParser.parseLine(lineStr);
                nextItem = lineMapper.toItem(lineParts);
            }
        }

        @Override
        public boolean hasNext() {
            return nextItem != null;
        }

        @Override
        public T next() {
            T item = nextItem;
            try {
                prepareNextItem();
            } catch (IOException | BadFormatException e) {
                NoSuchElementException noSuchElementException = new NoSuchElementException(e.getMessage());
                noSuchElementException.initCause(e);
                throw noSuchElementException;
            }
            return item;
        }
    }
}
