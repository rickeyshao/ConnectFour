package com.rickey.csv.exception;

public class BadFormatException extends Exception {
    public BadFormatException(String message) {
        super(message);
    }
}
