package com.rickey.csv.parser;

public class LineParseBuilder {
    private char separator = ILineParser.DEFAULT_SEPARATOR;
    private char escape = ILineParser.DEFAULT_ESCAPE;
    private boolean trimFieldValue = ILineParser.DEFAULT_TRIM_VALUE;

    public LineParseBuilder() {
    }

    /**
     * Set the separator.
     */
    public LineParseBuilder withSeparator(final char separator) {
        this.separator = separator;
        return this;
    }

    /**
     * Set the escape char.
     */
    public LineParseBuilder withEscape(final char escape) {
        this.escape = escape;
        return this;
    }

    /**
     * Set the escape char.
     */
    public LineParseBuilder withTrimFieldValue(final boolean trimFieldValue) {
        this.trimFieldValue = trimFieldValue;
        return this;
    }

    /**
     * Build a CsvLineParser instance.
     *
     * @return A new CsvLineParser with defined configurations.
     */
    public CsvLineParser build() {
        return new CsvLineParser(separator, escape, trimFieldValue);
    }
}
