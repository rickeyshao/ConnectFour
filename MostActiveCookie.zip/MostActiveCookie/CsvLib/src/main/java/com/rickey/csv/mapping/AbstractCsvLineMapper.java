package com.rickey.csv.mapping;

import java.util.Map;

//TODO implement a line mapper based on the annotation on the data model fields
public abstract class AbstractCsvLineMapper<T> implements IFieldNameLineMapper<T> {
    protected Class itemClass;

    public AbstractCsvLineMapper(Class itemClass) {
        this.itemClass = itemClass;
    }

    @Override
    public abstract Map<String, String> getFieldColumnMapping();

    @Override
    public Class getItemClass() {
        return itemClass;
    }

    @Override
    public T toItem(String[] line) {
        return null;
    }
}
